import React from 'react'
import contact from "../assets/contact.svg"

const Contact = () => {
  return (
   <>
   </>
  )
}

export default Contact